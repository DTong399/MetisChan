Moderating a Maniwani instance
------------------------------

Moderating an instance of Maniwani requires you to be logged into a slip
with either administration or moderator privileges, otherwise, the
moderation UI will not display.


Deleting a thread
-----------------

Click on the Delete link on the first post in the thread.


Deleting a post
---------------

Click on the Delete link next to the post.
