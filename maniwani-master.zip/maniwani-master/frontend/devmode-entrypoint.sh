#!/bin/sh

cd /maniwani-frontend
node server.js
