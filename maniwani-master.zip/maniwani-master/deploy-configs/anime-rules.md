* Non-anime images are generally allowed, but images in the OP must be of an anime origin.
* Discussion of Japanese games is not allowed on this board.

